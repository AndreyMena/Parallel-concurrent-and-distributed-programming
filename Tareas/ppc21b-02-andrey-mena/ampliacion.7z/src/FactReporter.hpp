// Copyright 2022 ECCI-UCR

#ifndef FACTREPORTER_H
#define FACTREPORTER_H

#include "FactCommon.hpp"

class FactReporter {
};

#endif  // FACTREPORTER_H
