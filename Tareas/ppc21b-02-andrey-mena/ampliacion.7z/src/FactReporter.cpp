// Copyright 2022 ECCI-UCR

#include <mpi.h>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "FactReporter.hpp"
