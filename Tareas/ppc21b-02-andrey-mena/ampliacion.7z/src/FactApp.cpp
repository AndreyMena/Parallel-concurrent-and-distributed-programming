// Copyright 2022 ECCI-UCR

#include <mpi.h>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <vector>

#include "FactApp.hpp"

FactApp::FactApp(int process_number, int process_count)
  : process_number(process_number)
  , process_count(process_count) {
}

void FactApp::run() {
  std::string file;
  std::vector<std::string> files;

  // TODO(you): distribute work
  (void)this->process_number;
  (void)this->process_count;

  // Read all filenames from stdin
  while (std::getline(std::cin, file)) {
    files.push_back(file);
  }

  // Factorize all files
  FactDecomposer decomposer;
  for (size_t index = 0; index < files.size(); ++index) {
    // TODO(you): send files to processes, Decomposers receive them
    decomposer.processFile(index, files[index]);
  }

  // TODO(you): Receive reports from Reporters and print them
  for (size_t index = 0; index < files.size(); ++index) {
    std::cout << files[index] << std::endl;
  }
}
