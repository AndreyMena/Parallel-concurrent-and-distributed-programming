## a1 < a2 < b1

  shared_x == 7
  print(5)

## a1 < b1 < a2

  shared_x == 7
  print(7)

## b1 < a1 < a2

  shared_x == 5
  print(5)
